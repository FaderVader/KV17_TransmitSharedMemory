﻿// =============================================================================
//
//   Copyright 2013 Vizrt Austria GmbH
//   All Rights Reserved.
//
//   This is PROPRIETARY SOURCE CODE of Vizrt Austria GmbH
//   the contents of this file may not be disclosed to third parties, copied or
//   duplicated in any form, in whole or in part, without the prior written
//   permission of Vizrt Austria GmbH
//
//  =============================================================================

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using Vizrt.VizCommunication;

namespace TestSendToSMM
{
    public partial class Form1 : Form
    {
        SendToSMM SendCollection;
        public Form1()
        {
            InitializeComponent();
            SendCollection = new SendToSMM();
        }

        private void addHost_Click(object sender, EventArgs e)
        {
            SendCollection.AddTcpHost(tbHost.Text);
        }

        private void RemoveHost_Click(object sender, EventArgs e)
        {
            SendCollection.RemoveTcpHost(tbHost.Text);
        }

        private void sendInt_Click(object sender, EventArgs e)
        {
            SendCollection.Send(tbIntKey.Text, Convert.ToInt16(tbIntVal.Text));
        }

        private void seriesInt_Click(object sender, EventArgs e)
        {
            for (int i = 1; i<10; i++)
            {
                SendCollection.Send(tbIntKey.Text + Convert.ToString(i), Convert.ToInt16(tbIntVal.Text) + i);
                Thread.Sleep(30);
            }
        }


        private void sendDbl_Click(object sender, EventArgs e)
        {
            SendCollection.Send(tbDblKey.Text, Convert.ToDouble(tbDblVal.Text));
        }

        private void precDbl_Click(object sender, EventArgs e)
        {
            SendCollection.Send(tbDblKey.Text, Convert.ToDouble(tbDblVal.Text),2);
        }

        private void sendStr_Click(object sender, EventArgs e)
        {
            SendCollection.Send(tbStrKey.Text, tbStrVal.Text);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            SendCollection.Cleanup();
        }

    }
}
