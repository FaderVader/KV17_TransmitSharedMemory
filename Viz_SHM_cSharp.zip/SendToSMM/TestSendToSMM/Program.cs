﻿// =============================================================================
//
//   Copyright 2013 Vizrt Austria GmbH
//   All Rights Reserved.
//
//   This is PROPRIETARY SOURCE CODE of Vizrt Austria GmbH
//   the contents of this file may not be disclosed to third parties, copied or
//   duplicated in any form, in whole or in part, without the prior written
//   permission of Vizrt Austria GmbH
//
//  =============================================================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace TestSendToSMM
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
