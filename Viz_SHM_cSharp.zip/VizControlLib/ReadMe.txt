=============
VizControlLib
=============

The VizControlLib is a C++ library containing classes that
simplify the creation of external control applications for Viz 3.x.

Currently, these classes are part of the VizControlLib:

SmmController
SmmUdpController
SmmValue
CommandClient
WinSocketException

More classes will be added in future versions of the VizControlLib.

Please refer to the respective header files in the include directory
for information on how to use these classes.

To build the VizControlLib, open the VizControlLib.sln solution file
in Visual Studio and build for Debug and Release. The output will
be created in the lib directory.

=================
VizControlLibTest
=================

The VizControlLibTest project demonstrates how to use the VizControlLib library
to send commands to a viz engine and how to control the shared memory map (SMM).
Please refer to the test/VizControlLibTest.cpp for more detailed information.
