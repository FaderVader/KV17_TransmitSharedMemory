#ifndef __VizControlLib_CommandClient_h__
#define __VizControlLib_CommandClient_h__

#include <vector>
#include <string>
#include <Winsock2.h>
#include <Windows.h>

namespace VizControl
{
    /*
    class CommandClient

    This class provides methods for communicating with a viz engine.
    */
    class CommandClient
    {
    public:
        CommandClient();
        ~CommandClient();

        // Opens a connection to a viz engine.
        void Open(const char* vizhost, unsigned short port);

        // Closes a connection. This method is called by the destructor.
        void Close();

        // Sends a command to the engine and returns the response string.
        // If you pass -1 for 'commandId', the response string is discarded.
        std::string SendCommand(int commandId, const std::string& command);

        // Unicode version of SendCommand.
        std::wstring SendCommand(int commandId, const std::wstring& command);

        // A structure holding an in-memory image.
        struct ImageData
        {
            ImageData() { width = 0; height = 0; bytesPerPixel = 0; }

            int width;
            int height;
            int bytesPerPixel;
            std::vector<unsigned char> pixels;
        };

        // Sends an icon request to viz. 'location' is the location of a database object
        // (e.g. "SCENE*foo/bar"). 'imageData' is filled by this method with the width and height
        // as well as the pixel data of the icon. The 'bytesPerPixel' member is always set to 3 (RGB).
        // To request a different icon size than the default size, set the 'width' and 'height' fields of the 'imageData'
        // object to the desired dimensions before calling this method.
        // If 'location' is invalid, 'imageData.width' and 'imageData.height' are set to 0.
        void SendIconRequest(const std::string& location, ImageData& imageData);

        // Sends a screen capture command to viz. The method fills 'imageData' to hold
        // the resulting image. The 'bytesPerPixel' member is always set to 4 (RGBA).
        // Note that 'imageData.width' and 'imageData.heigth' must be set to 0 before the call.
        // (It is currently not possible to request a different size than the default rendering size.)
        void SendCaptureCommand(ImageData& imageData);

    private:
        CommandClient(const CommandClient&);
        CommandClient& operator=(const CommandClient&);

        void ReceiveBytes(int n, unsigned char* outBuffer);
        int ReceiveInt();
        short ReceiveShort();
        unsigned char ReceiveByte();

        SOCKET m_socket;
    };
}

#endif
