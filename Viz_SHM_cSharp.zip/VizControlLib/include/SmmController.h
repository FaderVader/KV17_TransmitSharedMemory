#ifndef __VizControlLib_SmmController_h__
#define __VizControlLib_SmmController_h__

#include <string>
#include <vector>
#include "SmmValue.h"

namespace VizControl
{
    /*
    class SmmController

    This class is used to control the contents of a viz client's shared memory map (SSM).
    Call AddHost to specify the viz clients whose SSM you want to control.
    To change a value of a SSM element, call SetValue. If the specified key
    is not found in the SSM, a new element is created.
    CreateElement creates a new empty element in the map, DeleteElement deletes an element.

    This is an abstract class. To access its members, you must create an instance
    of a derived class (SmmUdpController being the only one at present).
    */
    class SmmController
    {
    public:
        SmmController();
        virtual ~SmmController();

        virtual void AddHost(const char* vizhost, unsigned short port) = 0;

        virtual void SetValue(const char* key, const SmmValue& value);
        void SetValueAndDistribute(const char* key, const SmmValue& value);
        void CreateElement(const char* key);
        void DeleteElement(const char* key);

    protected:
        virtual void SendRawString(const std::string& s) = 0;

    private:
        SmmController(const SmmController&);
        SmmController& operator=(const SmmController&);
    };
}

#endif
