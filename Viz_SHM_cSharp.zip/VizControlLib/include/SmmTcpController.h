#ifndef __VizControlLib_SmmTcpController_h__
#define __VizControlLib_SmmTcpController_h__

#include <vector>
#include <Winsock2.h>
#include <Windows.h>
#include "SmmController.h"

namespace VizControl
{
    /*
    class SmmTcpController

    This class implements the functionality of SmmController, enabling
    shared memory map (SSM) access via a TCP/IP connection.
    */
    class SmmTcpController : public SmmController
    {
    public:
        SmmTcpController();
        ~SmmTcpController();

        virtual void AddHost(const char* vizhost, unsigned short port); // overrides SmmController

    private:
        virtual void SendRawString(const std::string& s); // overrides SmmController

        SOCKET m_socket;
        std::vector<sockaddr> m_hosts;
    };
}

#endif
