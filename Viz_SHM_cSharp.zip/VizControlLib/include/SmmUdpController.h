#ifndef __VizControlLib_SmmUdpController_h__
#define __VizControlLib_SmmUdpController_h__

#include <vector>
#include <Winsock2.h>
#include <Windows.h>
#include "SmmController.h"

namespace VizControl
{
    /*
    class SmmUdpController

    This class implements the functionality of SmmController, enabling
    shared memory map (SSM) access via a UDP connection.
    */
    class SmmUdpController : public SmmController
    {
    public:
        SmmUdpController();
        ~SmmUdpController();

        virtual void AddHost(const char* vizhost, unsigned short port); // overrides SmmController
        virtual void SetValue(const char* key, const SmmValue& value);

    private:
        virtual void SendRawString(const std::string& s); // overrides SmmController
        void WaitForAcknowledge( size_t hostIndex );

        SOCKET m_socket;
        std::vector<sockaddr> m_hosts;

        bool m_bWaitForAck;
    };
}

#endif
