#ifndef __VizControlLib_SmmValue_h__
#define __VizControlLib_SmmValue_h__

#include <string>

namespace VizControl
{
    /*
    class SmmValue
    This class is used to hold a serialized representation of a value that
    can be stored in a shared memory map (SMM). In order to change the value
    of an SMM element, you first construct an SmmValue and then pass it to
    the SmmController's SetValue method.
    To construct an SmmValue object, you can either pass the the desired value
    to the constructor or you can construct an empty SmmValue object using
    the default constructor, followed by a call to one of Set* methods.
    The second option lets you fill the SmmValue object with compound data
    types such as vertices and arrays of SmmValue objects.
    Note that SetArray can be used to set the contents of an array as well as
    structure defined within a viz script.
    */
    class SmmValue
    {
    public:
        friend class SmmController;
        friend class SmmTcpController;
        friend class SmmUdpController;

        SmmValue()                          { }
        explicit SmmValue(bool v)           { SetBoolean(v); }
        explicit SmmValue(int v)            { SetInteger(v); }
        explicit SmmValue(double v)         { SetDouble(v); }
        explicit SmmValue(const char* s)    { SetString(s); }
        explicit SmmValue(const wchar_t* s) { SetString(s); }

        void SetBoolean(bool v);
        void SetInteger(int v);
        void SetDouble(double v);
        void SetString(const char* s);
        void SetString(const wchar_t* s);
        void SetVertex(double x, double y, double z);
        void SetMatrix(const double v[16]);
        void SetArray(const SmmValue* varArray, size_t size);

    private:
        std::string m_value;
    };
}

#endif
