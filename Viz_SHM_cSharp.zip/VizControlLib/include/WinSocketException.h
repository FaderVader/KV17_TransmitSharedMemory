#ifndef __VizControlLib_WinSocketException_h__
#define __VizControlLib_WinSocketException_h__

#include <exception>
#include <string>

namespace VizControl
{
    /*
    class WinSocketException

    A C++ exception that is thrown by members of SmmController and
    its derived classes in case of a socket error.
    */
    class WinSocketException : public std::exception
    {
    public:
        WinSocketException(const std::string& message) : m_message(message)
        {
        }

        virtual const char* what() const // overrides std::exception
        {
            return m_message.c_str();
        }

    private:
        std::string m_message;
    };
}

#endif
