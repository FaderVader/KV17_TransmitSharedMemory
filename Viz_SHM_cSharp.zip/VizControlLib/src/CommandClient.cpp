#include "stdafx.h"
#include "../include/CommandClient.h"
#include "../include/WinSocketException.h"
#include "Misc.h"

namespace VizControl
{
    CommandClient::CommandClient()
    {
        WSADATA winSockData;
        int err = WSAStartup(MAKEWORD(2, 2), &winSockData);
        assert(err == 0);

        m_socket = INVALID_SOCKET;
    }

    CommandClient::~CommandClient()
    {
        Close();

        int err = WSACleanup();
        assert(err == 0);
    }

    void CommandClient::Open(const char* vizhost, unsigned short port)
    {
        if (vizhost == NULL)
            throw std::invalid_argument("CommandClient::Open: vizhost == NULL");

        char portString[32];
        sprintf(portString, "%u", (unsigned int)port);

        addrinfo aiHints;
        addrinfo* aiList = NULL;
        memset(&aiHints, 0, sizeof(aiHints));
        aiHints.ai_family = AF_INET;
        aiHints.ai_socktype = SOCK_STREAM;
        aiHints.ai_protocol = IPPROTO_TCP;

        int ret = getaddrinfo(vizhost, portString, &aiHints, &aiList);
        if (ret != 0)
            ThrowSocketError(std::string("CommandClient::Open - cannot resolve hostname '") + vizhost + "'", ret);

        m_socket = WSASocket(AF_INET, SOCK_STREAM, IPPROTO_TCP, NULL, 0, 0);
        if (m_socket == INVALID_SOCKET)
            ThrowSocketError("CommandClient::Open - invalid socket");

        int err = connect(m_socket, aiList->ai_addr, sizeof(*aiList->ai_addr));
        if (err == SOCKET_ERROR)
        {
            closesocket(m_socket);
            m_socket = INVALID_SOCKET;
            ThrowSocketError(std::string("CommandClient::Open - cannot connect to '") + vizhost + "'");
        }
    }

    void CommandClient::Close()
    {
        if (m_socket != INVALID_SOCKET)
        {
            shutdown(m_socket, SD_SEND);
            closesocket(m_socket);
            m_socket = INVALID_SOCKET;
        }
    }

    std::string CommandClient::SendCommand(int commandId, const std::string& command)
    {
        if (m_socket == INVALID_SOCKET)
            throw std::logic_error("CommandClient::SendCommand - socket not open");

        char commandIdString[32];
        sprintf(commandIdString, "%d", commandId);
        std::string fullCommand = commandIdString;
        fullCommand += ' ';
        fullCommand += command;

        int ret = send(m_socket, fullCommand.c_str(), (int)fullCommand.length() + 1, 0);
        if (ret == SOCKET_ERROR)
            ThrowSocketError("CommandClient::SendCommand - send");

        std::string response;

        if (commandId == -1)
            return response;

        std::string responsePrefix = commandIdString;
        responsePrefix += ' ';

        const int bufferSize = 256;
        char a[bufferSize];

        for (;;)
        {
            int n = recv(m_socket, a, bufferSize, 0);

            if (n == SOCKET_ERROR)
                ThrowSocketError("CommandClient::SendCommand - recv");

            if (n == 0)
            {
                Close();
                return response;
            }

            for (int i = 0; i < n; i++)
            {
                if (a[i] == '\0')
                {
                    if (response.length() >= responsePrefix.length() && response.substr(0, responsePrefix.length()) == responsePrefix)
                    {
                        response.erase(0, responsePrefix.length());
                        return response;
                    }
                    else
                        response.clear();
                }

                response += a[i];
            }
        }
    }

    std::wstring CommandClient::SendCommand(int commandId, const std::wstring& command)
    {
        std::string response = SendCommand(commandId, UnicodeToUTF8(command.c_str()));
        return UTF8ToUnicode(response.c_str());
    }

    void CommandClient::ReceiveBytes(int n, unsigned char* outBuffer)
    {
        if (n < 0)
            throw std::invalid_argument("CommandClient::ReceiveBytes - n < 0");

        int count = 0; // number of bytes received
        while (count < n)
        {
            int bytesRead = recv(m_socket, (char*)outBuffer + count, n - count, 0);

            if (bytesRead == SOCKET_ERROR)
                ThrowSocketError("CommandClient::SendCommand - recv");

            if (bytesRead == 0)
            {
                Close();
                ThrowSocketError("CommandClient::SendIconRequest - connection closed by host");
            }

            count += bytesRead;
        }
    }

    int CommandClient::ReceiveInt()
    {
        unsigned char a[4];
        ReceiveBytes(4, a);
        return *(int*)a;
    }

    short CommandClient::ReceiveShort()
    {
        unsigned char a[2];
        ReceiveBytes(2, a);
        return *(short*)a;
    }

    unsigned char CommandClient::ReceiveByte()
    {
        unsigned char a;
        ReceiveBytes(1, &a);
        return a;
    }

    void CommandClient::SendIconRequest(const std::string& location, ImageData& imageData)
    {
        if (imageData.width < 0 || imageData.height < 0)
            throw std::invalid_argument("CommandClient::SendIconRequest - imageData.width < 0 || imageData.height < 0");

        if (location.empty())
            throw std::invalid_argument("CommandClient::SendIconRequest - location is empty");

        char a[64];
        sprintf(a, "%d %d", imageData.width, imageData.height);
        std::string command = "peak_get_icon " + location + " " + a;

        int ret = send(m_socket, command.c_str(), (int)command.length() + 1, 0);
        if (ret == SOCKET_ERROR)
            ThrowSocketError("CommandClient::SendIconRequest - send");

        imageData.width = Swap(ReceiveShort());
        imageData.height = Swap(ReceiveShort());
        imageData.bytesPerPixel = 3;

        if (imageData.width < 0 || imageData.height < 0)
            throw std::logic_error("CommandClient::SendIconRequest - imageData.width < 0 || imageData.height < 0");

        int imageSize = imageData.width * imageData.height * 3;
        imageData.pixels.resize(imageSize);

        if (imageSize == 0)
            return;

        unsigned char* pixelBuffer = &imageData.pixels[0];
        ReceiveBytes(imageSize, pixelBuffer);
    }

    void CommandClient::SendCaptureCommand(ImageData& imageData)
    {
        if (imageData.width != 0 || imageData.height != 0)
            throw std::invalid_argument("CommandClient::SendIconRequest - imageData.width != 0 || imageData.height != 0");

        std::string command = "peak_get_icon CAPTURE RENDERER FULL_FRAME RGBA -1 -1 RAW";

        int ret = send(m_socket, command.c_str(), (int)command.length() + 1, 0);
        if (ret == SOCKET_ERROR)
            ThrowSocketError("CommandClient::SendCaptureCommand - send");

        int ok = ReceiveInt();
        if (ok != 1)
        {
            while (ReceiveByte() != '\0'); // read remaining bytes of error string
            throw std::logic_error("Error in peak_get_icon CAPTURE");
        }

        // read header information
        unsigned char info[6];
        ReceiveBytes(6, info);
        int byteCount = ReceiveInt();
        assert(byteCount > 0);
        ReceiveBytes(6, info);
        int eight = ReceiveInt();
        assert(eight == 8);
        int width = ReceiveInt();
        int height = ReceiveInt();
        int pixelDataSize = ReceiveInt();

        imageData.width = width;
        imageData.height = height;
        imageData.bytesPerPixel = 4;

        std::vector<unsigned char> buffer(pixelDataSize);
        unsigned char* pixelBuffer1 = &buffer[0];

        // read pixel data
        ReceiveBytes(pixelDataSize, pixelBuffer1);

        imageData.pixels.resize(pixelDataSize);
        unsigned char* pixelBuffer2 = &imageData.pixels[0];

        // we need to flip the image vertically

        int bytesPerLine = width * 4;

        for (int y=0; y<height; y++)
            memcpy(pixelBuffer2 + (height - y - 1) * bytesPerLine, pixelBuffer1 + y * bytesPerLine, bytesPerLine);
    }
}
