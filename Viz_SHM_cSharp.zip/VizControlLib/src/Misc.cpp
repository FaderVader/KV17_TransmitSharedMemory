#include "stdafx.h"
#include "Misc.h"
#include "../include/WinSocketException.h"

namespace VizControl
{
    void ThrowSocketError(const std::string& message)
    {
        ThrowSocketError(message, WSAGetLastError());
    }

    void ThrowSocketError(const std::string& message, int errorCode)
    {
        char socketError[32];
        sprintf(socketError, "%d", errorCode);
        throw WinSocketException(message + " (WSAGetLastError = " + socketError + ")");
    }

    std::wstring UTF8ToUnicode(const char* s)
    {
        std::wstring res;

        if (s == NULL)
            return res;

        const unsigned char* p = (const unsigned char*)s;
        for (;;)
        {
            unsigned int c0 = *p;
            if (c0 == 0)
                break; // end of string

            p++;

            unsigned int f = c0 >> 4;

            if (f <= 7u)
            {
                res += (wchar_t)c0;
            }
            else if (f == 0xC || f == 0xD)
            {
                unsigned int c1 = *p;
                if ((c1 & (128 + 64)) != 128)
                    continue; // invalid character
                p++;

                wchar_t c = wchar_t(((c0 & 31) << 6) | (c1 & 63));
                res += c;
            }
            else if (f == 0xE)
            {
                unsigned int c1 = *p;
                if ((c1 & (128 + 64)) != 128)
                    continue; // invalid character
                p++;

                unsigned int c2 = *p;
                if ((c2 & (128 + 64)) != 128)
                    continue; // invalid character
                p++;

                wchar_t c = wchar_t(((c0 & 15) << 12) | ((c1 & 63) << 6) | (c2 & 63));
                res += c;
            }
            else
                continue; // invalid character
        }

        return res;
    }

    std::string UnicodeToUTF8(const wchar_t* s)
    {
        std::string res;

        if (s == NULL)
            return res;

        for (const unsigned short* p = (const unsigned short*)s;; p++)
        {
            unsigned int c = *p;
            if (c == 0)
                return res; // end of string

            if (c <= 0x7Fu)
            {
                res += (char)c;
            }
            else if (c <= 0x7FFu)
            {
                res += (char)((128 + 64) | (c >> 6));
                res += (char)(128 | (c & 63));
            }
            else
            {
                res += (char)((128 + 64 + 32) | (c >> 12));
                res += (char)(128 | ((c >> 6) & 63));
                res += (char)(128 | (c & 63));
            }
        }
    }
}
