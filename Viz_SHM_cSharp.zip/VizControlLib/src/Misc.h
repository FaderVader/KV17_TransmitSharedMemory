#ifndef __VizControlLib_Misc_h__
#define __VizControlLib_Misc_h__

namespace VizControl
{
    void ThrowSocketError(const std::string& message);
    void ThrowSocketError(const std::string& message, int errorCode);

    std::wstring UTF8ToUnicode(const char* s);
    std::string UnicodeToUTF8(const wchar_t* s);

    inline char GetHexDigit(unsigned int i)
    {
        assert(i >= 0 && i < 16);
        if (i <= 9)
            return '0' + (char)i;
        else
            return 'A' + (char)(i - 10);
    }

    inline unsigned short Swap(unsigned short n)
    {
        return n << 8 | n >> 8;
    }
}

#endif
