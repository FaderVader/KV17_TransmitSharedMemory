#include "stdafx.h"
#include "../include/SmmController.h"
#include "../include/WinSocketException.h"

namespace VizControl
{
    SmmController::SmmController()
    {
        WSADATA winSockData;
        int err = WSAStartup(MAKEWORD(2, 2), &winSockData);
        assert(err == 0);
    }

    SmmController::~SmmController()
    {
        int err = WSACleanup();
        assert(err == 0);
    }

    void SmmController::SetValue(const char* key, const SmmValue& value)
    {
        if (key == NULL)
            throw std::invalid_argument("SmmController::SetValue: key == NULL");

        SendRawString(std::string("SharedMemoryMap_SetValue|") + key + "|" + value.m_value);
    }

    void SmmController::SetValueAndDistribute(const char* key, const SmmValue& value)
    {
        if (key == NULL)
            throw std::invalid_argument("SmmController::SetValue: key == NULL");

        SendRawString(std::string("SharedMemoryMap_SetValueDistribute|") + key + "|" + value.m_value);
    }

    void SmmController::CreateElement(const char* key)
    {
        if (key == NULL)
            throw std::invalid_argument("SmmController::CreateElement: key == NULL");

        SendRawString(std::string("SharedMemoryMap_CreateElement|") + key);
    }

    void SmmController::DeleteElement(const char* key)
    {
        if (key == NULL)
            throw std::invalid_argument("SmmController::DeleteElement: key == NULL");

        SendRawString(std::string("SharedMemoryMap_DeleteElement|") + key);
    }
}
