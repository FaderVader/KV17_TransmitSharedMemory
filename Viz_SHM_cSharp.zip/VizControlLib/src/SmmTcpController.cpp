#include "stdafx.h"
#include "../include/SmmTcpController.h"
#include "Misc.h"

namespace VizControl
{
    SmmTcpController::SmmTcpController()
    {
        m_socket = INVALID_SOCKET;
    }

    SmmTcpController::~SmmTcpController()
    {
        if (m_socket != INVALID_SOCKET)
        {
            shutdown(m_socket, SD_SEND);
            closesocket(m_socket);
        }
    }

    void SmmTcpController::AddHost(const char* vizhost, unsigned short port)
    {
        if (vizhost == NULL)
            throw std::invalid_argument("SmmTcpController::AddHost: vizhost == NULL");

        if (m_socket == INVALID_SOCKET)
            m_socket = WSASocket(AF_INET, SOCK_STREAM, IPPROTO_TCP, NULL, 0, 0);

        if (m_socket == INVALID_SOCKET)
            ThrowSocketError("SmmController::AddHost - invalid socket");

        char portString[32];
        sprintf(portString, "%u", (unsigned int)port);

        addrinfo aiHints;
        addrinfo* aiList = NULL;
        memset(&aiHints, 0, sizeof(aiHints));
        aiHints.ai_family = AF_INET;
        aiHints.ai_socktype = SOCK_STREAM;
        aiHints.ai_protocol = IPPROTO_TCP;

        int ret = getaddrinfo(vizhost, portString, &aiHints, &aiList);
        if (ret != 0)
            ThrowSocketError(std::string("SmmController::Open - cannot resolve hostname '") + vizhost + "'", ret);

        m_hosts.push_back(*aiList->ai_addr);
    }


    void SmmTcpController::SendRawString(const std::string& s)
    {
        bool failed = false;

        for (size_t i = 0; i < m_hosts.size(); i++)
        {
            connect( m_socket, &m_hosts[i], sizeof(m_hosts[i]) );

            int err = sendto(m_socket, s.c_str(), (int)s.length() + 1, 0, &m_hosts[i], sizeof(m_hosts[i]));

            if (err == SOCKET_ERROR)
                failed = true;
        }

        if (failed)
            ThrowSocketError("SmmController::SendRawString - sendto failed");
    }
}
