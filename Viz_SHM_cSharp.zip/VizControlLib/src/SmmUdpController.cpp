#include "stdafx.h"
#include "../include/SmmUdpController.h"
#include "Misc.h"

namespace VizControl
{
    SmmUdpController::SmmUdpController()
    {
        m_socket = INVALID_SOCKET;
        m_bWaitForAck = false;
    }

    SmmUdpController::~SmmUdpController()
    {
        if (m_socket != INVALID_SOCKET)
        {
            shutdown(m_socket, SD_SEND);
            closesocket(m_socket);
        }
    }

    void SmmUdpController::AddHost(const char* vizhost, unsigned short port)
    {
        if (vizhost == NULL)
            throw std::invalid_argument("SmmUdpController::AddHost: vizhost == NULL");

        if (m_socket == INVALID_SOCKET)
            m_socket = WSASocket(AF_INET, SOCK_DGRAM, IPPROTO_UDP, NULL, 0, 0);

        if (m_socket == INVALID_SOCKET)
            ThrowSocketError("SmmController::AddHost - invalid socket");

        char portString[32];
        sprintf(portString, "%u", (unsigned int)port);

        addrinfo aiHints;
        addrinfo* aiList = NULL;
        memset(&aiHints, 0, sizeof(aiHints));
        aiHints.ai_family = AF_INET;
        aiHints.ai_socktype = SOCK_DGRAM;
        aiHints.ai_protocol = IPPROTO_UDP;

        int ret = getaddrinfo(vizhost, portString, &aiHints, &aiList);
        if (ret != 0)
            ThrowSocketError(std::string("SmmController::Open - cannot resolve hostname '") + vizhost + "'", ret);

        m_hosts.push_back(*aiList->ai_addr);
    }

    void SmmUdpController::WaitForAcknowledge( size_t hostIndex )
    {
        char buf[256];
        int fromLen = sizeof(m_hosts[0]);

        int ret = recvfrom( m_socket, buf, 1, 0, &m_hosts[hostIndex], &fromLen);

#ifdef _DEBUG
        if( ret > 0 )
            printf( "received acknowledge %d\n", ret );
#endif
    }

    void SmmUdpController::SetValue(const char* key, const SmmValue& value)
    {
        #define MAX_UDP_SIZE 65000

        if (key == NULL)
            throw std::invalid_argument("SmmController::SetValue: key == NULL");

        if( value.m_value.size() > MAX_UDP_SIZE ){
            char number[64];
            size_t  nPackets = value.m_value.size()/MAX_UDP_SIZE+1;

            for( size_t i = 0; i < nPackets; ++i ){
                sprintf( number, "%d|%d", i, nPackets );

                std::string sendString;

                const char *origStr =  value.m_value.c_str();
                size_t startIndex = i*MAX_UDP_SIZE;
                size_t endIndex = (i+1)*MAX_UDP_SIZE;

                if( endIndex > value.m_value.size() )
                    endIndex = value.m_value.size();

                sendString = &origStr[startIndex];
                sendString[endIndex-startIndex] = '\0';
                size_t strSize = sendString.size();
                sendString.resize( endIndex-startIndex );
                strSize = sendString.size();

                m_bWaitForAck = true;
                SendRawString(std::string("SharedMemoryMap_SetPartialValue|") + key + "|" + std::string(number) + "|" + sendString);

            }
        }else{
            m_bWaitForAck = false;
            SendRawString(std::string("SharedMemoryMap_SetValue|") + key + "|" + value.m_value);
        }
    }

    void SmmUdpController::SendRawString(const std::string& s)
    {
        bool failed = false;

        for (size_t i = 0; i < m_hosts.size(); i++)
        {
            int err = sendto(m_socket, s.c_str(), (int)s.length() + 1, 0, &m_hosts[i], sizeof(m_hosts[i]));

            if (err == SOCKET_ERROR)
                failed = true;
            else
               if( m_bWaitForAck ) WaitForAcknowledge(i);
        }

        if (failed)
            ThrowSocketError("SmmController::SendRawString - sendto failed");
    }
}
