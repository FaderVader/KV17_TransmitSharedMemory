#include "stdafx.h"
#include "../include/SmmValue.h"
#include "Misc.h"

namespace VizControl
{
    void SmmValue::SetBoolean(bool v)
    {
        m_value = v ? "1" : "0";
    }

    void SmmValue::SetInteger(int v)
    {
        char a[16];
        sprintf(a, "%d", v);
        m_value = a;
    }

    void SmmValue::SetDouble(double v)
    {
        char a[32];
        sprintf(a, "%.18g", v);
        m_value = a;
    }

    void SmmValue::SetString(const char* s)
    {
        m_value.clear();

        if (s == NULL)
            return;

        const char* p = s;

        while (*p != '\0')
        {
            char a = *p;
            if (isalnum(a) || a == '.' || a == '-' || a == '+')
                m_value += a;
            else
            {
                unsigned int digit = (unsigned int)a;
                m_value += '$';
                m_value += GetHexDigit((digit >> 4u) & 15u);
                m_value += GetHexDigit(digit & 15u);
            }

            p++;
        }
    }

    void SmmValue::SetString(const wchar_t* s)
    {
        SetString(UnicodeToUTF8(s).c_str());
    }

    void SmmValue::SetVertex(double x, double y, double z)
    {
        char a[80];
        sprintf(a, "%.18g_%.18g_%.18g", x, y, z);
        m_value = a;
    }

    void SmmValue::SetMatrix(const double v[16])
    {
        m_value.clear();
        char a[32];

        for (unsigned int i=0; i<16; i++)
        {
            sprintf(a, "%.18g", v[i]);
            m_value += a;
            if (i < 16)
                m_value += '_';
        }
    }

    void SmmValue::SetArray(const SmmValue* varArray, size_t size)
    {
        m_value.clear();

        for (size_t i = 0; i < size; i++)
        {
            m_value += "{";
            m_value += varArray[i].m_value;
            m_value += "} ";
        }
    }
}
