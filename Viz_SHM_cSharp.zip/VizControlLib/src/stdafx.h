// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#ifndef _DEBUG
#pragma warning (disable : 4189) // local variable is initialized but not referenced
#endif

#if defined(_WIN64)
#define VIZ_NEEDS_WINVERSION 0x601
#else // #if defined(_WIN64)
#define VIZ_NEEDS_WINVERSION 0x601
#endif // #if defined(_WIN64)

#define VIZTOSTRING(x) #x
#define VIZTOSTRING2(x) TOSTRING(x)
#if ! defined( _WIN32_WINNT )
#error "need to define _WIN32_WINNT to VIZTOSTRING2(VIZ_NEEDS_WINVERSION)"
#else // #if ! defined( _WIN32_WINNT )
#if _WIN32_WINNT != VIZ_NEEDS_WINVERSION
#pragma message( "_WIN32_WINNT is set to " VIZTOSTRING2(_WIN32_WINNT) )
#error "need to define _WIN32_WINNT to VIZTOSTRING2(VIZ_NEEDS_WINVERSION)."
#endif // #if _WIN32_WINNT != VIZ_NEEDS_WINVERSION
#endif // #if ! defined( _WIN32_WINNT )
#undef VIZTOSTRING
#undef VIZTOSTRING2
#undef VIZ_NEEDS_WINVERSION
#ifndef WINVER                  // Specifies that the minimum required platform is Windows XP with Service Pack 2.
#define WINVER _WIN32_WINNT     // Change this to the appropriate value to target other versions of Windows.
#endif




#if !defined(_WIN64)
#if !defined( _USE_32BIT_TIME_T )
#error "need to define _USE_32BIT_TIME_T for our 32 bit builds."
#define _USE_32BIT_TIME_T
#endif
#endif

#include <stdio.h>
#include <tchar.h>
#include <assert.h>

#define WIN32_LEAN_AND_MEAN

#include <Winsock2.h>
#include <Windows.h>
#include <Ws2tcpip.h>

#include <string>
#include <vector>
#include <exception>
