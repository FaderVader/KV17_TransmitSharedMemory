#include "stdafx.h"

/*

This program sends an icon request and a screen capture command to viz and stores the returned
image data in two CommandClient::ImageData objects.

Then, the program reads integer values from the console input until enter is pressed. The input values
are sent to the viz machine ("localhost") and port (3000) specified in the AddHost call, updating
the value of the SSM element identified by the key "RPM". For this to work, you need to make sure that in the
config file of the receiving viz host ("localhost" in our case), smm_udp_service is set to 3000.

Optionally there is an example further below that send huge (>64k) messages via UDP and/or TCP to
the viz machines (via port 3000 for udp and 3010 for tcp). smm_tcp_service must be set to 3010 in
your viz config file.

To verify that this program works, create a container with the following script. It will
print to the viz console the value of the "RPM" element whenever it is changed.

sub OnInit()
    ' Tell the script engine to call OnSharedMemoryVariableChanged whenever any value
    ' in the VizCommunication.Map is changed.
    VizCommunication.Map.RegisterChangedCallback("")
end sub

sub OnSharedMemoryVariableChanged(map As SharedMemory, mapKey As String)
    println mapKey  & "=" & map[mapkey]
end sub

*/

#include "../include/VizControl.h"

using namespace VizControl;

int wmain(int argc, wchar_t* argv[])
{
    try
    {
        //// Open a command interface connection with the viz engine.
        //CommandClient cc;
        //cc.Open("localhost", 6100);

        //// Query version number from viz.
        //std::string version = cc.SendCommand(0, "MAIN VERSION");
        //std::cout << version << std::endl;

        //// Send an icon request to viz
        //CommandClient::ImageData icon;
        //cc.SendIconRequest("SCENE*Foo/Bar", icon);
        //// 'icon' now contains the RGB image data of the requested icon

        //// Capture screen
        //CommandClient::ImageData screenshot;
        //cc.SendCaptureCommand(screenshot);
        //// 'screenshot' now contains the RGBA image data of the viz output window

        {
            // Create a SmmUdpController object to access the shared memory map (SSM) in viz.
            //SmmUdpController c;
            SmmTcpController c;
            c.AddHost("localhost", 3004);

            for (;;)
            {
                // Read integer values from the console input.
                std::cout << "Enter RPM value (or enter to quit): ";
                std::string input;
                std::getline(std::cin, input);
                if (input.empty())
                    break;

                //int rpmValue = atoi(input.c_str());

                // Set value of SSM element identified by the key "RPM".
                c.SetValue("RPM", SmmValue(input.c_str()));
            }
        }

        // send huge data via UDP
        //if( true )
        {
            // Create a SmmUdpController object to access the shared memory map (SSM) in viz.
            SmmUdpController c;
            c.AddHost("localhost", 3000);

            // Read integer values from the console input.
            std::cout << "Sending big UDP message\n";
            std::string input;

            input += "begin";

            char cc = 'a';
            for( int i = 0; i < 30*65535+1000; ++i ){
                input+= cc;
                cc = 'a'+i%26;
            }

            input += "end";

            FILE *file = fopen( "testoutUDP.txt", "w" );
            fprintf( file, "%s", input.c_str() );
            fclose( file );


            // Set value of SSM element identified by the key "RPM_UDP".
            c.SetValue("RPM_UDP", SmmValue(input.c_str()));
        }

        // send huge data via TCP
        //if( true )
        {
            // Create a SmmTcpController object to access the shared memory map (SSM) in viz.
            SmmTcpController c;
            c.AddHost("localhost", 3010);

            {
                // Read integer values from the console input.
                std::cout << "Sending big TCP message\n";
                std::string input;

                input += "begin";

                char cc = 'a';
                for( int i = 0; i < 30*65535+1000; ++i ){
                    input+= cc;
                    cc = 'a'+i%26;
                }

                input += "end";

                FILE *file = fopen( "testoutTCP.txt", "w" );
                fprintf( file, "%s", input.c_str() );
                fclose( file );

                // Set value of SSM element identified by the key "RPM_TCP".
                c.SetValue("RPM_TCP", SmmValue(input.c_str()));
            }
        }
    }
    catch (const WinSocketException& e)
    {
        std::cout << "WinSocketException: " << e.what() << std::endl;
    }

    return 0;
}
